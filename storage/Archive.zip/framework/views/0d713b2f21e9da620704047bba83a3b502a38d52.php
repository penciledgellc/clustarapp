			<tr>
				<td align="center" style="padding-bottom: 80px;">
					<table align="center" role="presentation" border="0" cellspacing="0" cellpadding="0" width="856" style="background: #ffffff; border-radius: 0 0 30px 30px; border-bottom: 2px solid #eee; border-left: 2px solid #eee; border-right: 2px solid #eee;">
						<tbody>
							<tr>
								<td style="font-size: 0px; padding: 0 60px 40px; word-break: break-word;">
									<div style="padding-top: 30px; border-top: 1px solid #DDDDDD;">
										<p style="font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif; width: 100%; font-size: 13px; color: rgba(0, 0, 0, 0.6); font-weight: 400; line-height: 22px; margin: 0;"><?php echo nl2br($copyright_text); ?></p>
									</div>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
	        </tr>
		</table>
	</body>	
</html>
<?php /**PATH /Applications/MAMP/htdocs/getclustar/resources/views/emails/email-footer.blade.php ENDPATH**/ ?>