
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">

	<head>
		<title>
		</title>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<!--<![endif]-->
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
	</head>
	<body style="margin: 0;">
		<table width="100%" align="center" border="0" cellpadding="0" cellspacing="0" style="background-color: #F6F6F6;">
			<tr>
				<td align="center">
					<table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" width="856" style="background: #F6F6F6;">
	                  <tbody>
	                    <tr>
	                      <td style="direction:ltr;font-size:0px;padding:80px 0 40px;text-align:center;">
	                        <div class="mj-column-per-100 mj-outlook-group-fix" style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
	                          <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="vertical-align:top;" width="100%">
	                            <tbody><tr>
	                              <td>
	                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:collapse;border-spacing:0px; margin: 0 auto;">
	                                  <tbody>
	                                    <tr>
	                                      <td style="width:137px;">
	                                        <img height="auto" src="<?php echo e($email_logo); ?>" style="border:0;display:block;outline:none;text-decoration:none;height:auto;width:100%;" width="130">
	                                      </td>
	                                    </tr>
	                                  </tbody>
	                                </table>
	                              </td>
	                            </tr>
	                          </tbody>
							</table>
	                        </div>
	                      </td>
	                    </tr>
	                  </tbody>
	                </table>
	            </td>
	        </tr><?php /**PATH /Applications/MAMP/htdocs/getclustar/resources/views/emails/email-header.blade.php ENDPATH**/ ?>