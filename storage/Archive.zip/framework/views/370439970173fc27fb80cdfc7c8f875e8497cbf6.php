<footer class="tb-footer-wrap">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="tb-copyright">
                    <p><?php echo e(__('general.copyright_txt',['year' => date('Y')])); ?></p>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /Applications/MAMP/htdocs/getclustar/resources/views/layouts/admin/footer.blade.php ENDPATH**/ ?>