<form class="at-themeform" id="at-form-setting_<?php echo e($block_key); ?>">
    <fieldset>
        <div class="at-themeform__wrap">
            <div wire:ignore class="form-group">
                <label class="at-label"><?php echo e(__('pages.page_content')); ?></label>
                <textarea id="tk_editor_<?php echo e(time()); ?>" class="form-control" name="page_content" placeholder="<?php echo e(__('pages.page_content')); ?>"></textarea>
            </div>
        </div>
    </fieldset>
</form><?php /**PATH /Applications/MAMP/htdocs/getclustar/resources/views/livewire/pagebuilder/settings/terms-condition-block.blade.php ENDPATH**/ ?>