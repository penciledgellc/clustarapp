<script defer src="<?php echo e(asset('common/js/bootstrap.min.js')); ?>"></script>
<script defer src="<?php echo e(asset('common/js/jquery.mCustomScrollbar.min.js')); ?>"></script>
<script defer src="<?php echo e(asset('js/main.js')); ?>"></script><?php /**PATH /Applications/MAMP/htdocs/getclustar/resources/views/layouts/footer_scripts.blade.php ENDPATH**/ ?>