
<div class="tk-section-skeleton">
    <?php for($i=0; $i < 3; $i++ ): ?>
        <div class="tk-box">
            <div class="tk-skelton-holder">
                <div class="tk-skeleton-left">
                    <figure class="tk-line tk-img-area"></figure>
                    <div class="tk-right-sk">
                        <div class="tk-right-sk-right">
                            <ul>
                                <li class="tk-line tk-skeletontwo"></li>
                                <li class="tk-line tk-skeletonthree"></li>
                            </ul>
                            <div class="tk-righ-sk-last">
                                <div class="tk-line tk-skeletonfour"></div>
                                <div class="tk-line tk-skeletonfive"></div>
                                <div class="tk-line tk-skeletonsix"></div>
                                <div class="tk-line tk-skeletonsix"></div>
                            </div>
                        </div>
                        <div class="tk-right-sk-end">
                            <div class="tk-line tk-skeletonseven"></div>
                            <div class="tk-line tk-skeletoneight"></div>
                            <div class="tk-line tk-skeletonbtn"></div>
                        </div>
                    </div>
                </div>
                <div class="tk-skeleton-bottom">
                    <ul>
                        <li class="tk-line tk-skeletonfull"></li>
                        <li class="tk-line tk-skeletonhalf"></li>
                    </ul>
                    <div class="tk-righ-sk-last">
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                        <div class="tk-line tk-skeletonfive"></div>
                    </div>
                </div>
            </div>
        </div>
    <?php endfor; ?>
</div> 
<?php /**PATH /Applications/MAMP/htdocs/getclustar/resources/views/components/search-skeleton.blade.php ENDPATH**/ ?>