<div class="tk-emptydata-holder">
    <div class="tk-emptydetails">
        <img src="<?php echo e(asset('images/empty.png')); ?>">
        <em><?php echo e(__('taxonomy.no_record')); ?></em>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/getclustar/resources/views/admin/no-record.blade.php ENDPATH**/ ?>