<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'tk-btn-solid-lg'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /Applications/MAMP/htdocs/getclustar/resources/views/components/button.blade.php ENDPATH**/ ?>